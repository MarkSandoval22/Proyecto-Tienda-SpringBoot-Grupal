/*Se crea la base de datos */
drop schema if exists rival;
drop user if exists usuario_prueba;
CREATE SCHEMA rival ;


/*Se crea un usuario para la base de datos llamado "usuario_prueba" y tiene la contraseña "Usuario_Clave."*/
create user 'usuario_prueba'@'%' identified by 'Usuar1o_Clave.';

/*Se asignan los prvilegios sobr ela base de datos TechShop al usuario creado */
grant all privileges on rival.* to 'usuario_prueba'@'%';
flush privileges;

/* la tabla de categoria contiene categorias de productos*/
create table rival.categoria (
  id_categoria INT NOT NULL AUTO_INCREMENT,
  descripcion VARCHAR(30) NOT NULL,
  ruta_imagen varchar(1024),
  activo bool,
  PRIMARY KEY (id_categoria))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4;

create table rival.producto (
  id_producto INT NOT NULL AUTO_INCREMENT,
  id_categoria INT NOT NULL,
  descripcion VARCHAR(30) NOT NULL,  
  detalle VARCHAR(1600) NOT NULL, 
  precio double,
  existencias int,  
  ruta_imagen varchar(1024),
  activo bool,
  PRIMARY KEY (id_producto),
  foreign key fk_producto_caregoria (id_categoria) references categoria(id_categoria)  
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4;

/*Se crea la tabla de clientes llamada cliente... igual que la clase Cliente */
CREATE TABLE rival.usuario (
  id_usuario INT NOT NULL AUTO_INCREMENT,
  username varchar(20) NOT NULL,
  password varchar(512) NOT NULL,
  nombre VARCHAR(20) NOT NULL,
  apellidos VARCHAR(30) NOT NULL,
  correo VARCHAR(25) NULL,
  telefono VARCHAR(15) NULL,
  ruta_imagen varchar(1024),
  activo boolean,
  PRIMARY KEY (`id_usuario`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4;

create table rival.factura (
  id_factura INT NOT NULL AUTO_INCREMENT,
  id_usuario INT NOT NULL,
  fecha date,  
  total double,
  estado int,
  PRIMARY KEY (id_factura),
  foreign key fk_factura_usuario (id_usuario) references usuario(id_usuario)  
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4;

create table rival.venta (
  id_venta INT NOT NULL AUTO_INCREMENT,
  id_factura INT NOT NULL,
  id_producto INT NOT NULL,
  precio double, 
  cantidad int,
  PRIMARY KEY (id_venta),
  foreign key fk_ventas_factura (id_factura) references factura(id_factura),
  foreign key fk_ventas_producto (id_producto) references producto(id_producto) 
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4;

/*Se insertan 3 registros en la tabla cliente como ejemplo */
INSERT INTO rival.usuario (id_usuario, username,password,nombre, apellidos, correo, telefono,ruta_imagen,activo) VALUES 
(1,'Marcel','$2a$10$P1.w58XvnaYQUQgZUCk4aO/RTRl8EValluCqB3S2VMLTbRt.tlre.','Marcel', 'Zapata Castro',    'mzapata@gmail.com',    '7108-8585', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTrj9o4ozFKt86aGMlaswRSviAmRHR23Oefmw&usqp=CAU',true),
(2,'Katherine','$2a$10$GkEj.ZzmQa/aEfDmtLIh3udIH5fMphx/35d0EYeqZL5uzgCJ0lQRi','Katherine',  'Vargas Herrera', 'kvargas@gmail.com', '8489-9695','https://vivolabs.es/wp-content/uploads/2022/03/perfil-mujer-vivo.png',true),
(3,'Pablo','$2a$10$koGR7eS22Pv5KdaVJKDcge04ZB53iMiw76.UjHPY.XyVYlYqXnPbO','Pablo', 'Fernandez Calderon',     'pfernandez@gmail.com','7265-7841','https://lapi.com.mx/web/image/product.template/5265/image_1024?unique=5f40446',true);

/*Se insertan 3 categorias de productos como ejemplo */
INSERT INTO rival.categoria (id_categoria,descripcion,ruta_imagen,activo) VALUES 
('1','Monitores', 'https://www.dotcom-monitor.com/wp-content/uploads/performance-reporting.png',   true), 
('2','Teclados',  'https://upload.wikimedia.org/wikipedia/commons/e/ed/Teclado_Brasileiro_Nativo.png',   true),
('3','Mouse','https://images.pexels.com/photos/7430756/pexels-photo-7430756.jpeg',true),
('4','Auriculares','https://gmedia.playstation.com/is/image/SIEPDC/3d-pulse-headset-product-thumbnail-01-en-14sep21?$facebook$',    false);



/*Se insertan 4 productos por categoria */
INSERT INTO rival.producto (id_producto,id_categoria,descripcion,detalle,precio,existencias,ruta_imagen,activo) VALUES
(1,1,'Monitor LG','LG 20MK400H-B - 20" - HDMI',45000,7,'https://extremetechcr.com/tienda/12436/lg-20mk400h-b.jpg',true),
(2,1,'Monitor X-Micro','X-MICRO X22KN - 22" - HDMI',48000,5,'https://www.techzilla.cr/wp-content/uploads/2022/10/MT2202-3.jpg',true),
(3,1,'Monitor ACER','ACER V206HQL',52000,3,'https://www.unimart.com/cdn/shop/products/1-4_1_d6e72329-ba59-4b71-a58f-b32ac5361379_large.jpg?v=1659968725',true),
(4,1,'Monitor ASUS','ASUS VP228HE - 22" - 1 MS',61000,4,'https://i0.wp.com/tiendasarcadia.com/wp-content/uploads/2022/09/VP228HE.jpeg?fit=265%2C190&ssl=1',true),
(5,2,'Teclado Redragon','REDRAGON DARK AVENGER - K568RGB-2',17000,3,'https://http2.mlstatic.com/D_NQ_NP_860827-MLA43976066837_112020-O.webp',true),
(6,2,'Teclado Razer','RAZER ORNATA V3X INGLES',20000,5,'https://extremetechcr.com/tienda/21888/razer-ornata-v3x-ingles.jpg',true),
(7,2,'Teclado XPG','XPG SUMMONER RGB-MX SILVER',25000,5,'https://www.intelec.co.cr/image/cache/catalog/catalogo/Teclado/SUMMONER4-250x250w.jpg',true),
(8,2,'Teclado Steelseries','STEELSERIES APEX 3 TKL -INGLES',29000,7,'https://media.steelseriescdn.com/thumbs/catalog/items/64817/66cb769f630643cab2b4af3b1ee37a4e.png.1400x1120_q100_crop-fit_optimize.png',true),
(9,3,'Mouse T-Dagger','T-DAGGER SERGEANT - T-TGM202',5500,12,'https://extremeoutletcr.com/1225-home_default/t-dagger-lieutenant-rgb-t-tgm301.jpg',true),
(10,3,'Mouse Checkpoint','CHECKPOINT MX100 RGB',6500,9,'https://m.media-amazon.com/images/I/51D8IyEEhgL.jpg',true),
(11,3,'Mouse HyperX','HYPERX PULSEFIRE HASTE 4P5P9AA',25000,6,'https://extremetechcr.com/tienda/14307/hyperx-pulsefire-haste-4p5p9aa.jpg',true),
(12,3,'Mouse Corsair','CORSAIR M65 RGB ELITE - NEGRO',25000,8,'https://www.unimart.com/cdn/shop/products/37-1_1_38e05c26-183a-4999-a6c6-a4a55af24992.jpg?v=1654064414',true),
(13,4,'Auriculares Adata','XPG PRECOG S',15000,10,'https://webapi3.adata.com/storage/product/precog_s_kv_mobile_480x850.jpg',true),
(14,4,'Auriculares Razer','RAZER KAIRA X PS BLANCO',32900,5,'https://m.media-amazon.com/images/I/414BdA9eIWL.jpg',true),
(15,4,'Auriculares HyperX','HYPERX CLOUD II ROJO',35000,6,'https://m.media-amazon.com/images/I/71MJ3OaVqBL._AC_UF894,1000_QL80_.jpg',true),
(16,4,'Auriculares Corsair','CORSAIR HS65 SURROUND NEGRO',38500,8,'https://www.unimart.com/cdn/shop/products/10-2_1_381ec735-223a-447f-aa85-7ddbdafdbe72_large.jpg?v=1673882307',true);

/*Se crean 6 facturas */   /*'Activa','Pagada','Anulada')*/
INSERT INTO rival.factura (id_factura,id_usuario,fecha,total,estado) VALUES
(1,1,'2022-01-05',35000,2),
(2,2,'2022-01-07',60900,2),
(3,3,'2022-01-07',87900,2),
(4,1,'2022-01-15',118000,1),
(5,2,'2022-01-17',113900,1),
(6,3,'2022-01-21',79500,1);

INSERT INTO rival.venta (id_venta,id_factura,id_producto,precio,cantidad) values
(1,1,5,17000,1),
(2,1,9,5500,1),
(3,1,10,6500,2),
(4,2,5,17000,1),
(5,2,14,32900,1),
(6,2,9,5500,2),
(7,3,14,32900,1),
(8,3,6,20000,1),
(9,3,15,35000,1),
(10,1,6,20000,1),
(11,1,8,29000,3),
(12,1,9,5500,2),
(13,2,8,29000,1),
(14,2,14,32900,1),
(15,2,3,52000,1),
(16,3,15,35000,1),
(17,3,12,25000,1),
(18,3,10,6500,3);

create table rival.rol (
  id_rol INT NOT NULL AUTO_INCREMENT,
  nombre varchar(20),
  id_usuario int,
  PRIMARY KEY (id_rol),
  foreign key fk_rol_usuario (id_usuario) references usuario(id_usuario)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4;

insert into rival.rol (id_rol, nombre, id_usuario) values
 (1,'ROLE_ADMIN',1), (2,'ROLE_VENDEDOR',1), (3,'ROLE_USER',1),
 (4,'ROLE_VENDEDOR',2), (5,'ROLE_USER',2),
 (6,'ROLE_USER',3);