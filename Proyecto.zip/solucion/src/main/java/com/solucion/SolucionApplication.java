package com.solucion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SolucionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SolucionApplication.class, args);
	}

}
